# go-skypeapi
### A skpe web api lib based on go.
#### The library is still being optimized, please use it with caution. Most functions can be tested.
#### This library refers to [SkPy](https://github.com/Terranc/SkPy) and [skype-http](https://github.com/ocilo/skype-http).
